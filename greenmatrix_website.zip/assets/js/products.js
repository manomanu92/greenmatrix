
const products = [
  {name:"Solar Panel", desc:"High efficiency panel"},
  {name:"Inverter", desc:"Smart inverter"}
];

let container = document.getElementById("products");

products.forEach(p=>{
  let div = document.createElement("div");
  div.innerHTML = `<h3>${p.name}</h3><p>${p.desc}</p>`;
  container.appendChild(div);
});
