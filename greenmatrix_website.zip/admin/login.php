<?php
session_start();
if($_POST){
 if($_POST['user']=="admin" && $_POST['pass']=="Green@123"){
  $_SESSION['admin']=true;
  header("Location: dashboard.php");
 }
}
?>
<form method="POST">
<input name="user">
<input name="pass" type="password">
<button>Login</button>
</form>
