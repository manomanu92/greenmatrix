<?php
session_start();
if(!isset($_SESSION['admin'])){die("Access denied");}
echo "Welcome to Admin Dashboard";
?>
