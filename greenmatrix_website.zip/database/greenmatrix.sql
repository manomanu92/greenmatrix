
CREATE DATABASE greenmatrix;
USE greenmatrix;

CREATE TABLE inquiries(
id INT AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(100),
email VARCHAR(100),
message TEXT
);
